from flask import Flask, render_template, request
from flask_socketio import SocketIO
from scapy.all import ARP, Ether, srp
import pyshark
import asyncio
import json


app = Flask(__name__)
socketio = SocketIO(app)

proto_counter = dict()
throughput_data = {'time': [], 'throughput': []}
dns_packets = []
top_talkers = {}


def process_packet(packet):
    try:
        global top_talkers
        protocol = packet.transport_layer
        source_ip = packet.ip.src
        destination_ip = packet.ip.dst
        # Update protocol counts
        proto_counter[protocol] = proto_counter.get(protocol, 0) + 1
        # Emit the updated data to all connected clients
        socketio.emit('update_data', proto_counter)
        
        
        #update DNS graph
        if hasattr(packet, 'dns'):
            dns_packets.append(packet)
            socketio.emit('dnspacket', packet.dns.qry_name)

        #updates for time line graph
        time = packet.sniff_timestamp
        throughput_value = len(str(packet))
        throughput_data['time'].append(time)
        throughput_data['throughput'].append(throughput_value)

        # Send the throughput data to all connected clients
        socketio.emit('update_throughput', throughput_data)

        #topTalkers
        source_ip = packet.ip.src

        # Update top_talkers dictionary with source IP as the key
        top_talkers[source_ip] = top_talkers.get(source_ip, 0) + 1
        # Send updates to the client
        socketio.emit('update_top_talkers', {
            'topTalkers': top_talkers
        })

        


    except AttributeError as e:
        # Ignore packets that don't contain the expected attributes
        pass

def live_sniff():
    global top_talkers
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    cap = pyshark.LiveCapture(interface='Wi-Fi')
    cap.sniff(timeout=100)  # Adjust as needed
    cap.apply_on_packets(process_packet)

    loop.run_until_complete(asyncio.gather())

@socketio.on('get_arp_results')
def get_arp_results():
    target_ip = "192.168.1.1/24"
    arp = ARP(pdst=target_ip)
    ether = Ether(dst="ff:ff:ff:ff:ff:ff")
    packet = ether / arp

    result = srp(packet, timeout=3, verbose=0)[0]
    clients = []

    for sent, received in result:
        clients.append({'ip': received.psrc, 'mac': received.hwsrc})

    socketio.emit('arp_results', {'clients': clients})


# Home route
@app.route('/')
def home():
    return render_template('index.html')

@socketio.on('message_from_client')
def handle_message(message):
    print('Message from client:', message)
    socketio.emit('message_from_server', message)
@app.route('/images/favicon.ico')
def favicon():
    return app.send_static_file('favicon.ico')


if __name__ == '__main__':

    socketio.start_background_task(live_sniff)
    socketio.run(app, debug=True)
